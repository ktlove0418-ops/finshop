const config = {
    // VUE_APP_API_URL: "https://brcapi.tallalla.com",
    VUE_APP_API_URL: "http://localhost:4000",
    VITE_API_UFA_URL:"https://www.eurowine8.com/Default8.aspx?lang=EN-GB",
    VUE_APP_VERSION: "1.0.0",
  };
  
  // Export config object
  export default config;